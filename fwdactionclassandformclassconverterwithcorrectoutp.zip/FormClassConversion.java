import java.io.*;
import java.util.*;

public class FormClassConversion {

public static void main(String args[]) throws IOException {
		String rootDirectory;
		
		System.out.println("Enter the path of root directory containing Form Classes");
		Scanner sc = new Scanner(System.in);
		rootDirectory = sc.nextLine();
		handleFormDirectory(rootDirectory);
	}

static void handleFormDirectory(String myDirectoryPath)throws IOException{
		int i,exitFlag;
		char ch;
		String buffer = "";
	
		File dir = new File(myDirectoryPath);		
		File[] directoryListing = dir.listFiles();
		
		if(directoryListing != null){
			for(File subDirectory : directoryListing){
				if(subDirectory.isDirectory()){
			//	System.out.println("name of dir:"+String.valueOf(subDirectory));
					handleFormDirectory(String.valueOf(subDirectory));
				}
				else{
					FileInputStream fin = new FileInputStream(subDirectory);
			//System.out.println("reading file :"+subDirectory);		
					while((i = fin.read()) != -1){
						ch = (char)i;
						if((ch == ' ') || (ch == '\n') || (ch == '{') || (ch == '(') || (ch == ',') || (ch == ')')){
							if(buffer.equals("extends")){
					//System.out.println("equals extends");		
								buffer = "";
								exitFlag = 0;
								while((i = fin.read()) != -1){
									ch = (char)i;
									if((ch == ' ') || (ch == '\n') || (ch == '{') || (ch == '.')){
										if(buffer.equals("ActionForm")){
						//	System.out.println("converting file :"+subDirectory);			
											convertFormClasses(subDirectory);
											break;
										}
										else if(ch == '\n'){
											exitFlag = 1;
											break;
										}
										else{
											buffer = "";
										}
									}
									else{
										buffer += ch;
									}
								}
								if(exitFlag == 1){
									break;
								}
							}
							else{
								buffer = "";
							}
						}
						else{
							buffer += ch;
						}
					}
					fin.close();
				}
			}
		}

}

	static void convertFormClasses(File subDirectory)throws IOException {
		String buffer = "";
		int i;
		char ch;
		byte b[];
		
		FileInputStream fin = new FileInputStream(subDirectory);
		File outputFile = new File("spring/"+subDirectory);
		outputFile.getParentFile().mkdirs();
		FileOutputStream fout = new FileOutputStream(outputFile);
		
	//	FileInputStream fin = new FileInputStream("FormClass.java");
	//	FileOutputStream fout = new FileOutputStream("spring/FormClass.java");
		
		//fin.read() returns ascii value of read char
		while((i = fin.read()) != -1) {
			ch = (char)i;
			if((ch == ' ') || (ch == '\n')) {
				/*if(buffer.equals("extends")) {
					handleActionForm(fin,fout);
					buffer = "";
				}*/
				//removing struts specific libraries
				if(buffer.equals("import")) {	
					buffer = "";
					while((i = fin.read()) != -1) {
						ch = (char)i;
						if(ch == '.') {
							if(buffer.equals("org.apache.struts")){		
								//ignore the line until end of line	
								while((i = fin.read()) != -1){
									ch = (char)i;
									if(ch == '\n'){
										break;
									}
								}		
								break;
							}
							else{		
								buffer += ch;
							}
							
						}
						else if(ch == '\n'){
							buffer = "import "+buffer+ch;
							System.out.print(buffer);
							b = buffer.getBytes();
							fout.write(b);
							break;
						}
						else{
							buffer += ch;
						}
					}		
					buffer = "";
				}
				else if((ch == ' ')||(ch == '\n')) {
					buffer += ch;
					System.out.print(buffer);
					b = buffer.getBytes();
					fout.write(b);
					buffer = "";					
				}
			}
			else {
				buffer += ch;
			}
		}
		
		fin.close();
		fout.close();
		
	/*	File oldfile = new File("FormClass.java");
		File newfile = new File("TemporaryFormClass.java");
		
		if(oldfile.delete()) {
			boolean success = newfile.renameTo(oldfile);
			if(!success) {
				System.out.println("File couldnt be renamed");
			}
		}
		else {
			System.out.println("Files could not be deleted ");
		}
		*/
	}
	
	static void handleActionForm(FileInputStream fin,FileOutputStream fout) throws IOException {
		ignoreUntil(fin,fout,"ActionForm");		//ignores till the word 'ActionForm'
	}
	
	static void ignoreUntil(FileInputStream fin,FileOutputStream fout,String str) throws IOException {		//ignores everything till String 'str'
		String buffer = "";
		char ch = ' ';
		int i;
		byte b[];
		
		while((i=fin.read())!=-1) {
			ch = (char)i;
			if((ch == ' ') || (ch == '\n') || (ch == '{') || (ch == '(') || (ch == '.')) {
				if(buffer.equals(str)) {
					break;
				}
				else{
					buffer = "";
				}
			}
			else if(ch == '\t'){
				//ignore
			}
			else {		
				buffer += ch;
			}
		}
		System.out.print(ch);
		buffer = "";
		buffer += ch;
		b = buffer.getBytes();
		fout.write(b);
	}

}

